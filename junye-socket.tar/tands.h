#ifndef SIMULATION_H
#define SIMULATION_H

void Trans(int n);

void Sleep(int n);

#endif