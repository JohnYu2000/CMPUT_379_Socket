#ifndef CLIENT_H
#define CLIENT_H

#include "client_socket_handler.h"

/**
* This is the main function that the client will run on.
*/
int main(int argc, char * argv[]);

#endif