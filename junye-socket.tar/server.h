#ifndef SERVER_H
#define SERVER_H

#include "server_socket_handler.h"

int main(int argc, char * argv[]);

#endif